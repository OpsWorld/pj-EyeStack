#-*- coding: utf-8 -*-

from django.shortcuts import render_to_response
from django.http import HttpResponse
import os, sys
import urllib2
import json
from django.contrib.auth.decorators import login_required


@login_required
def Home(request):
	return render_to_response('bigscreen/index.html')



def getMapData(request, ID):
    if str(ID) == '10000':
        url = 'http://172.16.100.21/url/index.php/Map/data?type=ct'
    elif str(ID) == '10010':
        url = 'http://172.16.100.21/url/index.php/Map/data?type=cu'
    elif str(ID) == '10086':
        url = 'http://172.16.100.21/url/index.php/Map/data?type=cm'
    else:
        pass
    req = urllib2.Request(url)
    result = urllib2.urlopen(req)
    res = result.read() 
    data_info = json.loads(res) 
    return HttpResponse(json.dumps(data_info), content_type="application/json")
