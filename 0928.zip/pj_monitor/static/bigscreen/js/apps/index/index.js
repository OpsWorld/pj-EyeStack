/**
 * 初始化引用模块组件
 * @desc
 * @version 2017/8/14 13:10
 */
define(function (require) {
    var layer = require('layer'),
        fullpage = require('fullpage'),
        echarts=require('echarts'),
        china=require('china')


    //初始化fullpage
    $('#fullpage').fullpage({
        'navigation':true,
        'slidesColor':'#fff',
        'continuousVertical': true,
        anchors: ['page3'],
        autoScrolling:true,
        id: 'pageContain',
        slidesNavigation:false,
        loopHorizontal:false,
        css3:true,

        onSlideLeave:function(anchorLink,index,slideIndex,direction){
            
        }
    });


     /*初始化地图*/
    var geoCoordMap = {
            '澳门':[113.54909,22.198951]
            ,'香港':[114.173355,22.320048]
            ,'台湾':[121.509062,25.044332]
            ,'广东':[113.280637,23.125178]
            ,'广西':[108.320004,22.82402]
            ,'海南':[110.33119,20.031971]
            ,'云南':[102.712251,25.040609]
            ,'福建':[119.306239,26.075302]
            ,'江西':[115.892151,28.676493]
            ,'湖南':[112.982279,28.19409]
            ,'贵州':[106.713478,26.578343]
            ,'浙江':[120.153576,30.287459]
            ,'安徽':[117.283042,31.86119]
            ,'上海':[121.4,31.1]
            ,'江苏':[118.767413,32.041544]
            ,'湖北':[114.298572,30.584355]
            ,'西藏':[91.132212,29.660361]
            ,'青海':[101.778916,36.623178]
            ,'甘肃':[103.823557,36.058039]
            ,'新疆':[87.617733,43.792818]
            ,'陕西':[108.948024,34.263161]
            ,'河南':[113.665412,34.757975]
            ,'山西':[112.549248,37.857014]
            ,'山东':[117.000923,36.675807]
            ,'河北':[114.502461,38.045474]
            ,'天津':[117.190182,39.125596]
            ,'北京':[116.405285,39.904989]
            ,'宁夏':[106.278179,38.46637]
            ,'内蒙古':[111.670801,40.818311]
            ,'辽宁':[123.429096,41.796767]
            ,'吉林':[125.3245,43.886841]
            ,'黑龙江':[126.642464,45.756967]
            ,'重庆':[106.504962,29.533155]
            ,'四川':[104.065735,30.659462]              
    };
    var mapData=[
            {name: '澳门',value: 60,bagRate:20 },
            {name: '香港',value: 50,bagRate:20 },
            {name: '台湾',value: 40,bagRate:20 },
            {name: '广东',value: 30,bagRate:20 },
            {name: '广西',value: 20,bagRate:20 },
            {name: '海南',value: 10,bagRate:20 },
            {name: '云南',value: 20,bagRate:20 },
            {name: '福建',value: 30,bagRate:20 },
            {name: '江西',value: 40,bagRate:20 },
            {name: '湖南',value: 50,bagRate:20 },
            {name: '贵州',value: 60,bagRate:20 },
            {name: '浙江',value: 70,bagRate:20 },
            {name: '安徽',value: 80,bagRate:20 },
            {name: '上海',value: 90,bagRate:20 },
            {name: '江苏',value: 80,bagRate:20 },
            {name: '湖北',value: 70,bagRate:20 },
            {name: '西藏',value: 60,bagRate:20 },
            {name: '青海',value: 50,bagRate:20 },
            {name: '甘肃',value: 40,bagRate:20 },
            {name: '新疆',value: 30,bagRate:20 },
            {name: '陕西',value: 20,bagRate:20 },            
            {name: '河南',value: 10,bagRate:20 },
            {name: '山西',value: 20,bagRate:20 },
            {name: '山东',value: 30,bagRate:20 },
            {name: '河北',value: 40,bagRate:20 },
            {name: '天津',value: 50,bagRate:20 },
            {name: '北京',value: 60,bagRate:20 },
            {name: '宁夏',value: 70,bagRate:20 },
            {name: '内蒙古',value: 80,bagRate:20 },
            {name: '辽宁',value: 90,bagRate:20 },
            {name: '吉林',value: 80,bagRate:20 },
            {name: '黑龙江',value: 70,bagRate:20 },
            {name: '重庆',value: 60,bagRate:20 },
            {name: '四川',value: 50,bagRate:20 }
    ];
    var tipTimer=null;


    function mapChartInit(mapData){

        $("#mapChart").empty().removeAttr('style _echarts_instance_');
        var myChart = echarts.init(document.getElementById('mapChart'));

        var color=['#0d9e03','#95d670','#cceb23','#e4ba18','#e55a24','#e40000'];

        var option = {
            title: {
                textStyle:{
                    color:'#fff',
                    fontWeight:'normal'
                },

                padding:[20,0,20,0],
                subtextStyle:{
                    color:'#fff'
                }
            },
            tooltip: {
                show:true,
                trigger: 'item',
                formatter:function(params){
                    // console.log(params)
                    return params.data.name+'<br/>响应时间：'+params.data.value+"ms<br/>"+"丢包率："+params.data.bagRate+"%"
                }
            },
            geo: {
                map: 'china',
                roam: true,
                label: {
                    normal: {
                        show: true,
                        color:'#000'
                    },
                    emphasis: {
                        show: true
                    }
                },
                left:'20%',
                top:'0',
                bottom:'15%',
                itemStyle: {
                    normal: {
                        borderColor: '#fff',
                        color:'rgba(255,255,255,1)'
                    },
                    emphasis: {
                        color:'#fd9c88'
                    }
                }
             },

            series: [
                {
                    type: 'map',
                    geoIndex: 0,
                    coordinateSystem: 'geo',
                    itemStyle: {
                        normal:{
                            color:function(params){

                                if(params.data.value<10){
                                    return color[0]
                                }else if(params.data.value>=10&&params.data.value<40){
                                    return color[1]
                                }else if(params.data.value>=40&&params.data.value<60){
                                    return color[2]
                                }else if(params.data.value>=60&&params.data.value<80){
                                    return color[3]
                                }else if(params.data.value>=80&&params.data.value<100){
                                    return color[4]
                                }else if(params.data.value>=100){
                                    return color[5]
                                }
                            }
                        }
                    },
                    markPoint:{
                        symbol:'image:///static/bigscreen/img/ifly-waring.png',
                        symbolSize:30,
                        label:{
                            normal:{
                                show:true,
                                color:'transparent'
                            }
                        },
                        itemStyle:{
                            normal:{
                                color:'#ff0000',
                                shadowBlur: 5,
                                shadowOffsetX:3,
                                shadowOffsetY:3,
                                shadowColor:'rgba(0,0,0,0.3)'
                            }
                        },
                        symbolOffset:[10,10],
                        data:[{
                            name:'上海',
                            coord:[121.4648,31.2891]
                        }]
                    },
                    data:mapData
                },{
                    type:'effectScatter',
                    coordinateSystem:'geo',
                    itemStyle:{
                        normal:{
                            color:'#cceb23'
                        }
                    },
                    symbolSize:'8',
                    rippleEffect: {

                        period: 3,
                        scale: 4.5,
                        brushType: 'fill',
                    },
                    data:(function(){
                        var arr=[];
                        for(var i=0;i<mapData.length;i++){
                            if(mapData[i].value>100||mapData[i].value==100){
                                arr.push(geoCoordMap[mapData[i].name])
                            }
                        }
                        return arr
                    })()
                }
            ]
        };

        myChart.setOption(option);

        tipTimer=setInterval(function(){
            
            var tipI=Math.round(Math.random()*mapData.length);

            $('#dataWarn').stop(true).fadeIn(200);
            $('#dataWarn').children('p').eq(0).html(mapData[tipI].name);
            $('#dataWarn').children('p').eq(1).children("span").html(mapData[tipI].value);
            $('#dataWarn').children('p').eq(2).children("span").html(mapData[tipI].bagRate);

            option.series[0].markPoint.data=[{
                name:mapData[tipI].name,
                coord:geoCoordMap[mapData[tipI].name]
            }];

            myChart.setOption(option);

        },2000)
    };



    /*切换效果*/

    function getTimes(){
        var mytime = new Date();
        var iYear = mytime.getFullYear();
        var month = mytime.getMonth()+1;
        var  day= mytime.getDate();
        var weekend = mytime.getDay();
        var hour = mytime.getHours();
        var min = mytime.getMinutes();
        var s = mytime.getSeconds();
        var str;
        if(weekend == 0){
            str = "星期日";
        }else if(weekend == 1){
            str = "星期一";
        }else if(weekend == 2){
            str = "星期二";
        }
        else if(weekend == 3){
            str = "星期三";
        }
        else if(weekend == 4){
            str = "星期四";
        }
        else if(weekend == 5){
            str = "星期五";
        }
        else if(weekend == 6){
            str = "星期六";
        }

        if(min<10){
            min='0'+min
        }
        if(s<10){
            s='0'+s
        }        
        return iYear+"年"+month+"月"+day+"日"+" "+str+" "+hour+":"+min+":"+s;
    }
    $("#mapChartDate").html(getTimes());
    setInterval(function(){
        $("#mapChartDate").html(getTimes())
    },1000);

    function mapChange(ele,url){

        ele.siblings('li').removeClass('active');
        ele.addClass('active');

        $("#mapChart").stop(true).fadeOut(500).fadeIn(500);

        var po=$(".ifly-map-wap .network-type").children('li.active').index();
            if(po==0){
                url='/getMapDataApi/10000/'
            }else if(po==1){
                url='/getMapDataApi/10010/'
            }else{
                url='/getMapDataApi/10086/'
            }

        $.get(url,function(data){

            for(var i = 0;i < mapData.length; i++) {
                if(!data['avg'][i]){
                    mapData[i]['value']='0';
                    mapData[i]['bagRate']='0';

                }else{
                    mapData[i]['value']=data['avg'][i];
                    mapData[i]['bagRate']=data['loss'][i];
                }
            }
            clearInterval(tipTimer);
            mapChartInit(mapData);

        })
    }; 

    $(".ifly-map-wap .network-type").children('li').on('click',function(){

        mapChange($(this))

    });    

    // 自动滚动效果
    var scrollTimer=setInterval(mapset,1000);

    function mapset(){

             if($('.section.active').attr('data-anchor')=='page3'){
                
                clearInterval(scrollTimer);
                $(".ifly-map-wap .network-type").children('li').removeClass('active').eq(0).addClass('active');
                clearInterval(tipTimer);
                
                 $.get('/getMapDataApi/10000/',function(data){

                    for(var i = 0;i < mapData.length; i++) {
                        if(!data['avg'][i]){
                            mapData[i]['value']='0';
                            mapData[i]['bagRate']='0';

                        }else{
                            mapData[i]['value']=data['avg'][i];
                            mapData[i]['bagRate']=data['loss'][i];
                        }
                    }
                    clearInterval(tipTimer);
                    mapChartInit(mapData);

                })
                
                var po=1;
                var threeSetInterval=setInterval(function(){
                    clearInterval(threeSetInterval);
                    setTimeout(function(){
                        scrollTimer=setInterval(mapset,10000);
                    },10000)

                },20000);

             };

    }


});
