from django.conf.urls import patterns, include, url


# urlpatterns = patterns('apps.accounts.views',
#     url(r'^login/$', 'user.login', name='loginurl'),
#     url(r'^logout/$', 'user.logout', name='logouturl'),
#     url(r'^index/$', 'user.index', name='indexurl'),
#     url(r'^haha/$', 'user.haha', name='hahaurl'),    
# )


urlpatterns = patterns('apps.accounts.views',
    url(r'^login/$', 'user.LoginUser', name='loginurl'),
    url(r'^logout/$', 'user.LogoutUser', name='logouturl'),

    url(r'^user/list/$', 'user.ListUser', name='listuserurl'),
 )


