#-*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser

# Create your models here.
class ParentList(models.Model):
    name = models.CharField(max_length=64)

    def __unicode__(self):
        return '%s' %self.name

class PermissionList(models.Model):
    name = models.CharField(max_length=64)
    url = models.CharField(max_length=255)
    parent = models.ForeignKey(ParentList, null=True, blank=True)   
    is_show = models.BooleanField(default=False)

    def __unicode__(self):
        return '%s(%s)' %(self.name,self.url)
                                              
class RoleList(models.Model):
    name = models.CharField(max_length=64)
    permission = models.ManyToManyField(PermissionList, null=True, blank=True)

    def __unicode__(self):
        return self.name

class UserManager(BaseUserManager):
    def create_user(self,email,username,password=None):
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email = self.normalize_email(email),
            username = username,
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self,email,username,password):
        user = self.create_user(email,
            username = username,
            password = password,
        )

        user.is_active = True
        user.is_superuser = True
        user.save(using=self._db)
        return user

class User(AbstractBaseUser):
    username = models.CharField(max_length=40, unique=True, db_index=True)
    nickname = models.CharField(max_length=64, null=True, blank=True)
    email = models.EmailField(max_length=255)
    tel = models.CharField(max_length=11, null=True, blank=True)
    wchat = models.CharField(max_length=100, null=True, blank=True)
    is_active = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    sex = models.CharField(max_length=2, null=True, blank=True)
    role = models.ForeignKey(RoleList, null=True, blank=True)

    objects = UserManager()
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    def has_perm(self,perm,obj=None):
        if self.is_active and self.is_superuser:
            return True

