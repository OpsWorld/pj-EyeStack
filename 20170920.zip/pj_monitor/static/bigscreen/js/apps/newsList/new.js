﻿$('#sd').on('click',function () {
    $(this).css('color','red');
    alert('添加成功！')
});