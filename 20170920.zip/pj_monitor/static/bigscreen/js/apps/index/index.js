/**
 * 初始化引用模块组件
 * @desc
 * @auth junji
 * @version 2017/8/14 13:10
 */
define(function (require) {
    var layer = require('layer'),
        iflyPieChart = require('iflyPieChart'),
        fullpage = require('fullpage'),
        echarts=require('echarts'),
        china=require('china')


    /*退出系统*/
    $('#iflyuiSignOut').on('click', function(){
        layer.confirm('您确认退出系统吗？', {
            btn: ['确定','取消'], //按钮
            icon:3,
            title:'退出确认',
            shade: .8,
            shadeClose: true
        }, function(){
            layer.msg('你点击了退出确认');
            /*window.location.href = ctx + "logout.do" ;*/
        }, function(){
            layer.msg('你点击了取消');
        });
    });

    /*比例初始化*/
    var pieInit=(function(){

         data=[
         {
            "node":"合肥",
            //地域
            "data":{
                "server":{
                    //资源类型
                    "c_down": "10",
                    //异常总数
                    "total": "100",
                    //总数
                    "percent": "10"
                    //占比
                },
                "network":{
                    "c_down": "20",
                    "total": "200",
                    "percent": "10"
                },
                "middleware":{
                    "c_down": "50",
                    "total": "200",
                    "percent": "40"
                }                   
            }
         },{
            "node":"北京",
            //地域
            "data":{
                "server":{
                    //资源类型
                    "c_down": "10",
                    //异常总数
                    "total": "200",
                    //总数
                    "percent": "10"
                    //占比
                },
                "network":{
                    "c_down": "50",
                    "total": "200",
                    "percent": "40"
                },
                "middleware":{
                    "c_down": "50",
                    "total": "200",
                    "percent": "40"
                }                   
            }
         },{
            "node":"广州",
            //地域
            "data":{
                "server":{
                    //资源类型
                    "c_down": "80",
                    //异常总数
                    "total": "100",
                    //总数
                    "percent": "80"
                    //占比
                },
                "network":{
                    "c_down": "20",
                    "total": "200",
                    "percent": "10"
                },
                "middleware":{
                    "c_down": "50",
                    "total": "200",
                    "percent": "40"
                }                   
            }
         }];

        init=function(){

            for(var i=0;i<data.length;i++){

                var htm='<li>'
                    +'<div id="a-circle" class="c100 p'+data[i].data.server.percent+' big"><ol class="ad">'
                    +'<li class="y1">'+data[i].data.server.percent+'%</li><li class="y2">'+data[i].data.server.c_down+'</li><li class="y3">总服务器数'+data[i].data.server.total+'</li></ol>'
                    +'<ol class="slice"><li class="bar"></li><li class="fill"></li></ol><div class="bar-bg"></div>'
                    +'</div><div class="name">主机设备</div>'
                    +'</li>'
                    +'<li>'
                    +'<div id="b-circle" class="c100 p'+data[i].data.network.percent+' big"><ol class="ad">'
                    +'<li class="y1">'+data[i].data.network.percent+'%</li><li class="y2">'+data[i].data.network.c_down+'</li><li class="y3">总网络数'+data[i].data.network.total+'</li></ol>'
                    +'<ol class="slice"><li class="bar"></li><li class="fill"></li></ol><div class="bar-bg"></div>' 
                    +'</div><div class="name">网络设备</div></li>'   
                    +'<li>'
                    +'<div id="c-circle" class="c100 p'+data[i].data.middleware.percent+' big"><ol class="ad"><li class="y1">'+data[i].data.middleware.percent+'%</li><li class="y2">'+data[i].data.middleware.c_down+'</li><li class="y3">总组件数'+data[i].data.middleware.total+'</li></ol>'
                    +'<ol class="slice"><li class="bar"></li><li class="fill"></li></ol>'
                    +'<div class="bar-bg"></div></div><div class="name">组件</div>'
                    +'</li>';

                    $("#citySlide").children('.slide').eq(i).find('ul').html(htm)
            }

            circleInit()
        };
        return {
            init:init
        }
        
    })()

    pieInit.init();


    //初始化fullpage
    $('#fullpage').fullpage({
        'navigation':true,
        'slidesColor':'#fff',
        'continuousVertical': true,
        anchors: ['page1', 'page2', 'page3', 'page4', 'page5'],
        // easingcss3: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)',
        autoScrolling:true,
        id: 'pageContain',
        slidesNavigation:false,
        loopHorizontal:false,
        css3:true,
        afterLoad: function(anchorLink, index){
            
            if(index == 4||index == 5){
                if(!$("#iflyTop").hasClass('ifly-box-top-warn')){
                    $("#iflyTop").addClass('ifly-box-top-warn')
                }
            }
        },
        onLeave: function(index, direction){
           
            if(index == 5 && direction==1){
                if($("#iflyTop").hasClass('ifly-box-top-warn')){
                    $("#iflyTop").removeClass('ifly-box-top-warn')
                }
                
            }
            if(index == 4 && direction==3){
                if($("#iflyTop").hasClass('ifly-box-top-warn')){
                    $("#iflyTop").removeClass('ifly-box-top-warn')
                }
                
            }
        },
        afterSlideLoad:function(anchorLink,index,slideIndex,direction){

            if(anchorLink=='page1'){
                $(".ifly-tabs[datatype=ifly-tabs]").children('li').removeClass('ifly-this');
                $(".ifly-tabs[datatype=ifly-tabs]").children('li').eq(slideIndex).addClass('ifly-this')
            }
        },
        onSlideLeave:function(anchorLink,index,slideIndex,direction){
            
        }
    });


     //初始化echart 饼状图
     (function(){

         var myChart = echarts.init(document.getElementById('pieChart'));
         var option = {
            backgroundColor: 'transparent',

            title: {
                text: 'CPU利用率（400）',
                left: 'center',
                top: 20,
                textStyle: {
                    color: '#fff',
                    fontWeight:'normal'
                }
            },

            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },

            color:['#9fd55b','#23e9f5','#4261d3','#7587f7','#f4852c'],

            legend: {
                left:'center',
                data:['0','10%','30%','50%','80%'],
                textStyle:{
                    color:'#fff'
                },
                aligh:'right',
                bottom:20,
                itemHeight:'4',
                itemGap:20,
                formatter: function (name) {
                    switch(name){

                        case '0': return '0~10%';
                        break;

                        case '10%': return '10%~30%';
                        break;

                        case '30%': return '30%~50%';
                        break;

                        case '50%': return '50%~80%';
                        break;

                        case '80%': return '80%~100%';
                        break;
                    }
                }
            },
            series : [
                {
                    name:'CPU利用率',
                    type:'pie',
                    radius : "55%",
                    center: ['50%', '50%'],
                    data:[
                        {value:335, name:'0'},
                        {value:310, name:'10%'},
                        {value:274, name:'30%'},
                        {value:235, name:'50%'},
                        {value:400, name:'80%'}
                    ],
                    roseType: 'radius',
                    label: {
                        normal: {
                            show: true,
                            textStyle: {
                                color: 'rgba(255, 255, 255, 0.8)'
                            },
                            formatter:function(params){
                                return params.name+'（'+params.value+'）' 
                            }
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                color: 'rgba(255, 255, 255, 1)'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: true,
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.8)'
                            },
                            smooth: 0,
                            length: 10,
                            length2: 20
                        },
                        emphasis: {
                            show: true
                        }
                    },
                    animationType: 'scale',
                    animationEasing: 'elasticOut',
                    animationDelay: function (idx) {
                        return Math.random() * 200;
                    }
                }
            ]
        };

        myChart.setOption(option)

     })();
    
    //初始化曲线图
    (function(){

        var myChart=echarts.init(document.getElementById('lineChart'));

        var data = [];
        var xAxisData=['0时','1时','2时','3时','4时','5时','6时','7时','8时','9时','10时','11时','12时'];
        // var now = +new Date(1997, 9, 3);
        // var oneDay = 24 * 3600 * 1000;
         // var value = parsInt(Math.random() * 1000);
         for (var i = 0; i < 12; i++) {
             data.push({
                name:'2017',
                value:parseInt(Math.random() * 1000)
             });
         }

        var option = {
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    params = params[0];
                    return params.name + ' : ' + params.value;
                },
                axisPointer: {
                    animation: false
                }
            },
            xAxis: {
                type: 'category',
                axisLine:{
                    lineStyle:{
                        color:'#33388b'
                    }
                },
                axisTick:{
                    lineStyle:{
                        color:'#0acad6'
                    }
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a1c0f4'
                    }
                },
                splitLine: {
                    show: false
                },
                data: xAxisData
            },
            yAxis: {
                type: 'value',
                boundaryGap: [0, '100%'],
                axisLine:{
                    lineStyle:{
                        color:'#33388b'
                    }
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a1c0f4'
                    }
                },
                splitLine: {
                    show: false
                }
            },
            series: [{
                name: '模拟数据',
                type: 'line',
                showSymbol: true,
                hoverAnimation: false,
                symbol:'image:// /static/bigscreen/img/two/ifly-node-bg.png',
                symbolSize:20,
                itemStyle : {  
                    normal : {  
                        color:'#fff',
                        lineStyle:{  
                            color:'#0f9ab3'  
                        }  
                    }  
                },  
                areaStyle:{
                    normal: {
                        color:{
                            type: 'linear',
                            x: 0,
                            y: 0,
                            x2: 0,
                            y2: 1,
                            colorStops: [{
                                offset: 0, color: '#0f9ab3' // 0% 处的颜色
                            },{
                                offset: 1, color: 'transparent' // 100% 处的颜色
                            }],
                            globalCoord: false // 缺省为 false
                        }
                    }
                    
                },
                smooth:true,
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ],
                    symbolSize:'30',
                    label:{
                        normal:{
                            color:'#a5c5f4',
                            fontSize:'16',
                            padding:[0,0,0,50],
                        }
                    },
                    itemStyle:{
                        normal:{
                            color:{
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0, color: '#fda18a' // 0% 处的颜色
                                }, {
                                    offset: 1, color: '#f85c72' // 100% 处的颜色
                                }],
                                globalCoord: false // 缺省为 false
                            }
                        }
                    }
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'}
                    ],
                    symbol:'pin',
                    symbolSize:'0',
                    label:{
                        normal:{
                            color:'#ff4231',
                            fontSize:'16',
                            padding:[0,0,25,0]
                        }
                    },
                    lineStyle:{
                        normal:{
                            color:'#474b8f'
                        }
                        
                    }
                },
                data: data
            }]
        };

        setInterval(function () {
            data.shift();
            data.push({
                name:'2017',
                value:parseInt(Math.random() * 1000)
            });

            var num=parseInt(xAxisData[xAxisData.length-1]);

            if(num>=23){
                num=0
            }else{
                num+=1
            }
            xAxisData.shift();
            xAxisData.push(num+'时')

            myChart.setOption({
                xAxis:{
                    data:xAxisData
                },
                series: [{
                    data: data
                }]
            });
        }, 1000);

        myChart.setOption(option);

    })();

    // 初始化告警方式柱状图
    (function(){

        var myChart=echarts.init(document.getElementById('columnChart')); 
        var color=['#8094ff','#8094ff']
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    data : ['微信', '邮件', 'QQ', '电话'],
                    axisLine:{
                        lineStyle:{
                            color:'#6b83bd'
                        }
                    },
                    axisTick:{
                        lineStyle:{
                            color:'#0acad6'
                        }
                    },
                    splitLine: {
                        show: false
                    }
                }

            ],
            yAxis : [
                {
                    type : 'value',
                    axisLine:{
                        lineStyle:{
                            color:'#6b83bd'
                        }
                    },
                    axisTick:{
                        lineStyle:{
                            color:'#0acad6'
                        }
                    },
                    splitLine: {
                        show: false
                    }
                }
            ],
            series : [
                {
                    name:'通知方式',
                    type:'bar',
                    barWidth: '40%',
                    label:{
                        normal:{
                            show:true,
                            position:'top',
                            color:'#fff'
                        }
                    },
                    data:[10, 52, 200, 334],
                    itemStyle:{
                        normal:{
                            color:function(params){
                                if(params.dataIndex%2==1){
                                    return color[1]
                                }else{
                                    return color[0]
                                }
                            }
                        }
                    }
                }
            ]
        };

        myChart.setOption(option);
    })();

    //初始化告警总览柱状图
    (function(){
        var color=[
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 1,
                y2: 0,
                colorStops: [{
                    offset: 0, color: '#f2994a' // 0% 处的颜色
                }, {
                    offset: 1, color: '#f2c94c' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            },
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 1,
                y2: 0,
                colorStops: [{
                    offset: 0, color: '#ca2b00' // 0% 处的颜色
                }, {
                    offset: 1, color: '#f8b000' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            },
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 1,
                y2: 0,
                colorStops: [{
                    offset: 0, color: '#e43a15' // 0% 处的颜色
                }, {
                    offset: 1, color: '#e65245' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }
        ];
        var myChart=echarts.init(document.getElementById('annularChart'));
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            legend: {
                textStyle:{
                    color:'#fff'
                },
                padding:[20,0,0,0],
                itemGap:50,
                data: ['已处理', '未响应']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis:  {
                type: 'value',
                axisLine:{
                    lineStyle:{
                        color:'#6b83bd'
                    }
                },
                axisTick:{
                    lineStyle:{
                        color:'#0acad6'
                    }
                },
                splitLine: {
                    show: false
                }
            },
            yAxis: {
                type: 'category',
                data: ['一般','严重','灾难'],
                axisLine:{
                    lineStyle:{
                        color:'transparent'
                    }
                },
                axisLabel:{
                    color:'#fff',
                    backgroundColor:{
                        image: '/static/bigscreen/img/two/ifly-side.png'
                    },
                    padding:[5,20,5,20],
                    margin:18
                }
            },
            barCategoryGap:'65%',
            series: [
                {
                    name: '已处理',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            color: '#fff',
                            show: true,
                            position: 'insideRight'
                        }
                    },
                    itemStyle:{
                        normal:{
                            color:function(params){
                                return color[params.dataIndex]; 
                            }
                        }
                    },
                    markLine : {
                        symbol:'pin',
                        symbolSize:'0',
                        label:{
                            normal:{
                                show:false
                            }
                        },
                        data : [
                            {type : 'average', name: '平均值'}
                        ]
                    },
                    data: [220,150,200]
                },
                {
                    name: '未响应',
                    type: 'bar',
                    stack: '总量',
                    itemStyle:{
                        normal:{
                            color:'rgba(255,255,255,0.5)'
                        }
                    },
                    data: [80,80,50]
                }
            ]
        };
        myChart.setOption(option);

    })();

     /*初始化地图*/
    var geoCoordMap = {
            '台湾':[121.509062,25.044332]
            ,'河北':[114.502461,38.045474]
            ,'山西':[112.549248,37.857014]
            ,'内蒙古':[111.670801,40.818311]
            ,'辽宁':[123.429096,41.796767]
            ,'吉林':[125.3245,43.886841]
            ,'黑龙江':[126.642464,45.756967]
            ,'江苏':[118.767413,32.041544]
            ,'浙江':[120.153576,30.287459]
            ,'安徽':[117.283042,31.86119]
            ,'福建':[119.306239,26.075302]
            ,'江西':[115.892151,28.676493]
            ,'山东':[117.000923,36.675807]
            ,'河南':[113.665412,34.757975]
            ,'湖北':[114.298572,30.584355]
            ,'湖南':[112.982279,28.19409]
            ,'广东':[113.280637,23.125178]
            ,'广西':[108.320004,22.82402]
            ,'海南':[110.33119,20.031971]
            ,'四川':[104.065735,30.659462]
            ,'贵州':[106.713478,26.578343]
            ,'云南':[102.712251,25.040609]
            ,'西藏':[91.132212,29.660361]
            ,'陕西':[108.948024,34.263161]
            ,'甘肃':[103.823557,36.058039]
            ,'青海':[101.778916,36.623178]
            ,'宁夏':[106.278179,38.46637]
            ,'新疆':[87.617733,43.792818]
            ,'北京':[116.405285,39.904989]
            ,'天津':[117.190182,39.125596]
            ,'上海':[121.4,31.1]
            ,'重庆':[106.504962,29.533155]
            ,'香港':[114.173355,22.320048]
            ,'澳门':[113.54909,22.198951]
    };
    var mapData=[
            {name: '澳门',value: 60,bagRate:20 },
            {name: '香港',value: 50,bagRate:20 },
            {name: '台湾',value: 40,bagRate:20 },
            {name: '广东',value: 30,bagRate:20 },
            {name: '广西',value: 20,bagRate:20 },
            {name: '海南',value: 10,bagRate:20 },
            {name: '云南',value: 20,bagRate:20 },
            {name: '福建',value: 30,bagRate:20 },
            {name: '江西',value: 40,bagRate:20 },
            {name: '湖南',value: 50,bagRate:20 },
            {name: '贵州',value: 60,bagRate:20 },
            {name: '浙江',value: 70,bagRate:20 },
            {name: '安徽',value: 80,bagRate:20 },
            {name: '上海',value: 90,bagRate:20 },
            {name: '江苏',value: 80,bagRate:20 },
            {name: '湖北',value: 70,bagRate:20 },
            {name: '西藏',value: 60,bagRate:20 },
            {name: '青海',value: 50,bagRate:20 },
            {name: '甘肃',value: 40,bagRate:20 },
            {name: '新疆',value: 30,bagRate:20 },
            {name: '陕西',value: 20,bagRate:20 },            
            {name: '河南',value: 10,bagRate:20 },
            {name: '山西',value: 20,bagRate:20 },
            {name: '山东',value: 30,bagRate:20 },
            {name: '河北',value: 40,bagRate:20 },
            {name: '天津',value: 50,bagRate:20 },
            {name: '北京',value: 60,bagRate:20 },
            {name: '宁夏',value: 70,bagRate:20 },
            {name: '内蒙古',value: 80,bagRate:20 },
            {name: '辽宁',value: 90,bagRate:20 },
            {name: '吉林',value: 80,bagRate:20 },
            {name: '黑龙江',value: 70,bagRate:20 },
            {name: '重庆',value: 60,bagRate:20 },
            {name: '四川',value: 50,bagRate:20 }
    ];
    var tipTimer=null;


    function mapChartInit(mapData){

        $("#mapChart").empty().removeAttr('style _echarts_instance_');
        var myChart = echarts.init(document.getElementById('mapChart'));

        var color=['#0d9e03','#95d670','#cceb23','#e4ba18','#e55a24','#e40000'];

        var option = {
            title: {
                textStyle:{
                    color:'#fff',
                    fontWeight:'normal'
                },

                padding:[20,0,20,0],
                subtextStyle:{
                    color:'#fff'
                }
            },
            tooltip: {
                show:true,
                trigger: 'item',
                formatter:function(params){
                    console.log(params)
                    return params.data.name+'<br/>响应时间：'+params.data.value+"ms<br/>"+"丢包率："+params.data.bagRate+"%"
                }
            },
            geo: {
                map: 'china',
                roam: true,
                label: {
                    normal: {
                        show: true,
                        color:'#000'
                    },
                    emphasis: {
                        show: true
                    }
                },
                left:'20%',
                top:'0',
                bottom:'15%',
                itemStyle: {
                    normal: {
                        borderColor: '#fff',
                        color:'rgba(255,255,255,1)'
                    },
                    emphasis: {
                        color:'#fd9c88'
                    }
                }
             },

            series: [
                {
                    type: 'map',
                    geoIndex: 0,
                    coordinateSystem: 'geo',
                    itemStyle: {
                        normal:{
                            color:function(params){

                                if(params.data.value<10){
                                    return color[0]
                                }else if(params.data.value>=10&&params.data.value<40){
                                    return color[1]
                                }else if(params.data.value>=40&&params.data.value<60){
                                    return color[2]
                                }else if(params.data.value>=60&&params.data.value<80){
                                    return color[3]
                                }else if(params.data.value>=80&&params.data.value<100){
                                    return color[4]
                                }else if(params.data.value>=100){
                                    return color[5]
                                }
                            }
                        }
                    },
                    markPoint:{
                        symbol:'image:///static/bigscreen/img/ifly-waring.png',
                        symbolSize:30,
                        label:{
                            normal:{
                                show:true,
                                color:'transparent'
                            }
                        },
                        itemStyle:{
                            normal:{
                                color:'#ff0000',
                                shadowBlur: 5,
                                shadowOffsetX:3,
                                shadowOffsetY:3,
                                shadowColor:'rgba(0,0,0,0.3)'
                            }
                        },
                        symbolOffset:[10,10],
                        data:[{
                            name:'上海',
                            coord:[121.4648,31.2891]
                        }]
                    },
                    data:mapData
                },{
                    type:'effectScatter',
                    coordinateSystem:'geo',
                    itemStyle:{
                        normal:{
                            color:'#cceb23'
                        }
                    },
                    symbolSize:'8',
                    rippleEffect: {

                        period: 3,
                        scale: 4.5,
                        brushType: 'fill',
                    },
                    data:(function(){
                        var arr=[];
                        for(var i=0;i<mapData.length;i++){
                            if(mapData[i].value>100||mapData[i].value==100){
                                arr.push(geoCoordMap[mapData[i].name])
                            }
                        }
                        return arr
                    })()
                }
            ]
        };

        myChart.setOption(option);

        tipTimer=setInterval(function(){
            
            var tipI=Math.round(Math.random()*mapData.length);

            $('#dataWarn').stop(true).fadeIn(200);
            $('#dataWarn').children('p').eq(0).html(mapData[tipI].name);
            $('#dataWarn').children('p').eq(1).children("span").html(mapData[tipI].value);
            $('#dataWarn').children('p').eq(2).children("span").html(mapData[tipI].bagRate);

            option.series[0].markPoint.data=[{
                name:mapData[tipI].name,
                coord:geoCoordMap[mapData[tipI].name]
            }];

            myChart.setOption(option);

        },2000)
    };

    /*切换效果*/
    // $(".ifly-map-wap .network-type").children('li').on('click',function(){

    //     mapChange($(this))

    // });

    function getTimes(){
        var mytime = new Date();
        var iYear = mytime.getFullYear();
        var month = mytime.getMonth()+1;
        var  day= mytime.getDate();
        var weekend = mytime.getDay();
        var hour = mytime.getHours();
        var min = mytime.getMinutes();
        var s = mytime.getSeconds();
        var str;
        if(weekend == 0){
            str = "星期日";
        }else if(weekend == 1){
            str = "星期一";
        }else if(weekend == 2){
            str = "星期二";
        }
        else if(weekend == 3){
            str = "星期三";
        }
        else if(weekend == 4){
            str = "星期四";
        }
        else if(weekend == 5){
            str = "星期五";
        }
        else if(weekend == 6){
            str = "星期六";
        }

        if(min<10){
            min='0'+min
        }
        if(s<10){
            s='0'+s
        }        
        return iYear+"年"+month+"月"+day+"日"+" "+str+" "+hour+":"+min+":"+s;
    }
    $("#mapChartDate").html(getTimes());
    setInterval(function(){
        $("#mapChartDate").html(getTimes())
    },1000);

    function mapChange(ele,url){

        ele.siblings('li').removeClass('active');
        ele.addClass('active');

        $("#mapChart").stop(true).fadeOut(500).fadeIn(500);
        $("#mapChart").empty().removeAttr('style _echarts_instance_');

        $.get(url,function(data){

            for(var i = 0;i < mapData.length; i++) {
                mapData[i]['value']=data['avg'][i];
                mapData[i]['bagRate']=data['loss'][i];
            }
            clearInterval(tipTimer);
            mapChartInit(mapData);

        })
    }; 

    // 自动滚动效果
    var tip=true;
    var num=0;
    var scrollTimer=setInterval(mapset,4000);

    function mapset(){
         if(tip){
             $.fn.fullpage.moveTo('page1', num);

             if(num==2){
                 tip=false;
                 num=0;
             }else{
                 num++
             }

         }else{

             $.fn.fullpage.moveSectionDown();

             if($('.section.active').attr('data-anchor')=='page2'){
                 $("#iflyTabs").children('li').removeClass('ifly-this');
                 $("#iflyTabs").children('li:first').addClass('ifly-this');
                 $("#citySlide").find(".fp-slidesContainer").css('transform','translate3d(0px, 0px, 0px)');
                 $("#citySlide").find(".fp-slidesContainer").children('.fp-slide').removeClass('active');
                 $("#citySlide").find(".fp-slidesContainer").children('.fp-slide:first').addClass('active');
             }

             if($('.section.active').attr('data-anchor')=='page3'){
                
                clearInterval(scrollTimer);
                $(".ifly-map-wap .network-type").children('li').removeClass('active').eq(0).addClass('active');
                clearInterval(tipTimer);
                
                 $.get('http://127.0.0.1:8000/getMapDataApi/10000/',function(data){

                    for(var i = 0;i < mapData.length; i++) {
                        mapData[i]['value']=data['avg'][i];
                        mapData[i]['bagRate']=data['loss'][i];
                    }
                    clearInterval(tipTimer);
                    mapChartInit(mapData);

                })
                
                var po=1;
                var threeSetInterval=setInterval(function(){
                    var url=null;
 
                    if(po<2||po==2){
                        if(po==0){
                            url='http://127.0.0.1:8000/getMapDataApi/10000/'
                        }else if(po==1){
                            url='http://127.0.0.1:8000/getMapDataApi/10010/'
                        }else{
                            url='http://127.0.0.1:8000/getMapDataApi/10086/'
                        }
                        console.log(url);
                        mapChange($(".ifly-map-wap .network-type").children('li').eq(po),url);
                    }

                    po+=1;

                    if(po==3){
                        clearInterval(threeSetInterval);
                        setTimeout(function(){
                            scrollTimer=setInterval(mapset,4000);
                        },8000)
                    }

                },10000);

             };

             if($('.section.active').attr('data-anchor')=='page5'){
                tip=true
             }

         }
    }


});