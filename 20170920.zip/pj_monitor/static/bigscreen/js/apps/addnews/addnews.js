﻿/**
 * 初始化引用模块组件
 * @desc
 * @auth junji
 * @version 2017/8/14 13:10
*/
define(function (require) {
    var layer = require('layer'),
        common = require('common'),
        test = require('test')

		//返回
    	common.back("[datatype='back']");
		
		//loading加载：true显示，false隐藏
		common.loading(false)
		
		//表单提交：包含校验，提交成功提示
		$('#save').on('click',function(){
			//表单校验
			
			//成功提示
			common.msgBox('保存成功','icon-success');
		})
		
});