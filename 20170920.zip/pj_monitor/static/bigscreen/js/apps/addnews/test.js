﻿(function(){
	console.log('加载非AMD规范模块test.js成功！');
})()