$(function(){
    $("input[placeholder]").placehoderComp();
})
$.fn.extend({
    // placehoder兼容性写法
    placehoderComp:function(){
    	
        var supportPlaceholder='placeholder'in document.createElement('input');
        if(!supportPlaceholder){

            $(this).each(function(){
                var self=$(this);
                var warnTip=self.attr("placeholder");

                self.val(warnTip);
                self.css({
                    "color":"#999"
                })
                self.focus(function(){
                    if(self.val()==warnTip){
                        self.val("");  
                        self.css({
                            "color":"#333"
                        })                      
                    }
                });

                self.blur(function(){

                    if(self.val()==""){

                        self.val(warnTip);
                        self.css({
                            "color":"#999"
                        })
                    }
                    
                });
            })
        }
    	

    }

})





