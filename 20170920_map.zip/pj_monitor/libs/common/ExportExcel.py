# # -*-coding:utf-8 -*-
# #__author__ = 'Zline'

# import datetime
# import xlwt
# import cStringIO

# # from django.db.models.query import QuerySet, ValuesQuerySet
# from django.db.models.query import QuerySet
# from django.http import HttpResponse
# from apps.alert.models import AlertList

# class ExcelResponse(HttpResponse):
#     response = HttpResponse(content_type='application/vnd.ms-excel')
#     response[
#         'Content-Disposition'] = 'attachment;filename={0}-{1}.xls'.format(site_name, jira_version)
#     wb = xlwt.Workbook(encoding='utf-8')
#     sheet_prd = wb.add_sheet(u'历史告警')
#     # sheet_uat = wb.add_sheet('UAT')
#     # sheet_fat = wb.add_sheet('FAT')

#     style_heading = xlwt.easyxf("""
#         font:
#             name Arial,
#             colour_index white,
#             bold on,
#             height 0xA0;
#         align:
#             wrap off,
#             vert center,
#             horiz center;
#         pattern:
#             pattern solid,
#             fore-colour 0x19;
#         borders:
#             left THIN,
#             right THIN,
#             top THIN,
#             bottom THIN;
#         """
#                                 )
#     style_body = xlwt.easyxf("""
#         font:
#             name Arial,
#             bold off,
#             height 0XA0;
#         align:
#             wrap on,
#             vert center,
#             horiz left;
#         borders:
#             left THIN,
#             right THIN,
#             top THIN,
#             bottom THIN;
#         """
#                              )
#     style_green = xlwt.easyxf(" pattern: pattern solid,fore-colour 0x11;")
#     style_red = xlwt.easyxf(" pattern: pattern solid,fore-colour 0x0A;")
#     fmts = [
#         'M/D/YY',
#         'D-MMM-YY',
#         'D-MMM',
#         'MMM-YY',
#         'h:mm AM/PM',
#         'h:mm:ss AM/PM',
#         'h:mm',
#         'h:mm:ss',
#         'M/D/YY h:mm',
#         'mm:ss',
#         '[h]:mm:ss',
#         'mm:ss.0',
#     ]
#     style_body.num_format_str = fmts[0]
#     # 1st line
#     sheet_prd.write(0, 0, '发布单', style_heading)
#     sheet_prd.write(0, 1, '组件', style_heading)
#     sheet_prd.write(0, 2, '环境', style_heading)
#     sheet_prd.write(0, 3, '进度', style_heading)
#     sheet_prd.write(0, 4, 'JIRA问题号', style_heading)
#     sheet_prd.write(0, 5, '操作用户', style_heading)
#     sheet_prd.write(0, 6, '时间', style_heading)

#     row = 1
#     contents = AlertList.objects.filter(status=0)
#     for content in contents:
#         sheet_prd.write(row, 0, content.name, style_body)
#         sheet_prd.write(row, 1, content.app_name.name, style_body)
#         sheet_prd.write(row, 2, content.deploy_status, style_body)
#         if content.deploy_progress == u'已发布':
#             sheet_prd.write(row, 3, content.deploy_progress, style_green)
#         else:
#             sheet_prd.write(row, 3, content.deploy_progress, style_red)
#         sheet_prd.write(row, 4, content.jira_issue_no, style_body)
#         sheet_prd.write(row, 5, str(content.create_user), style_body)
#         sheet_prd.write(row, 6, str(content.change_date + timedelta(hours=8)), style_body)

#         # 第一行加宽
#         sheet_prd.col(0).width = 100 * 50
#         sheet_prd.col(1).width = 200 * 50
#         sheet_prd.col(2).width = 50 * 50
#         sheet_prd.col(3).width = 50 * 50
#         sheet_prd.col(4).width = 200 * 50
#         sheet_prd.col(5).width = 50 * 50
#         sheet_prd.col(6).width = 200 * 50
#         row += 1

#     # 1st line
#     sheet_uat.write(0, 0, '发布单', style_heading)
#     sheet_uat.write(0, 1, '组件', style_heading)
#     sheet_uat.write(0, 2, '环境', style_heading)
#     sheet_uat.write(0, 3, '进度', style_heading)
#     sheet_uat.write(0, 4, 'JIRA问题号', style_heading)
#     sheet_uat.write(0, 5, '操作用户', style_heading)
#     sheet_uat.write(0, 6, '时间', style_heading)



#     output = StringIO.StringIO()
#     wb.save(output)
#     output.seek(0)
#     response.write(output.getvalue())
#     return response