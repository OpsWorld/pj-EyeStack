﻿$(function(){

    //layui表单监控事件
    layui.use(['form'], function() {
        form = layui.form();

        //设置置顶定时
        form.on('checkbox(setTopTime)',function(){
            if(this.checked){
                $('#setTopTimeover').css('visibility','visible');
            }
            else{
                $('#setTopTimeover').css('visibility','hidden');
            }
        })

        //设置置顶定时
        form.on('checkbox(setTopTime)',function(){
            if(this.checked){
                $('#setTopTimeover').css('visibility','visible');
            }
            else{
                $('#setTopTimeover').css('visibility','hidden');
            }
        })

    });

})

//定义关闭窗口刷新iframe方法
function iflyRefish (url){
    parent.$('#main_iframe').attr('src',url)
};

/*
定义iflyConfirm
 *  titles  标题
*   msg     信息正文
*   success 成功提示
*   url     成功之后刷新iframe的链接
*/
function iflyConfirm (titles,msg,success,url){
    parent.layer.confirm(msg, {
        btn: ['确定','取消'], //按钮
        icon:3,
        title:titles,
        shade: .8,
        shadeClose: true
    }, function(index){
        parent.layer.msg(success);
        parent.layer.close(index);
        iflyRefish(url);
    }, function(){

    });
};

//取消置顶
function resetTop(){
    iflyConfirm('取消置顶','确定取消置顶吗？','取消置顶成功','../homePush/index.html')
}

//移除首页
function removeHome(){
    iflyConfirm('移除首页','确定移除首页吗？','移除首页成功','../homePush/index.html')
}

//信息发布
function releaseMsg(){
    iflyConfirm('确认发布','确定发布该信息吗？','信息发布成功','../homePush/index.html')
}
//取消发布
function cancelReleaseMsg(){
    iflyConfirm('取消发布','确定取消发布信息吗？','取消发布信息成功','../homePush/index.html')
}
//确认删除
function deleteMsg(){
    iflyConfirm('确认删除','确定删除信息吗？','信息删除成功','../homePush/index.html')
}

//设置置顶
function setTop() {
    parent.layer.open({
        type: 2,
        title: '确定将该资讯设为置顶吗？',
        shadeClose: true,
        shade: .8,
        area: ['450px', '420px'],
        content:'../../../WEB-INF/views/news/setTop.html'
    })
};

//推送首页
function pushHome() {
    parent.layer.open({
        type: 2,
        title: '确定将该资讯推送APP首页吗？',
        shadeClose: true,
        shade: .8,
        area: ['450px', '420px'],
        content:'../../../WEB-INF/views/news/pushHome.html'
    })
};