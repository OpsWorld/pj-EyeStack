﻿/**
 * 初始化引用模块组件
 * @desc
 * @auth junji
 * @version 2017/8/14 13:10
*/
define(function (require) {
    var layer = require('layer'),
        common = require('common'),
        template = require('template'),
        pagination = require('pagination')
        WdatePicker = require('WdatePicker'),

    	//common.loading()
		
		//弹出层
		$('#search').on('click', function(){
			parent.layer.open({
				btn :['确定'],
				skin :'ifly-layer',
				type : 2,
				title : '模态框',
				shade : .8,
				area : ['540px', '420px'],
				shadeClose : true,
				content:[ '../../../WEB-INF/views/news/top.html'],
				yes : function(index){
					parent.layer.msg('你点击了确定！');
					parent.layer.close(index)	
				},
				btn2 : function(index){
					parent.layer.msg('你点击了取消！');
					parent.layer.close(index)	
				},
				cancel : function(index){
					parent.layer.msg('你点击了关闭！');
					parent.layer.close(index)	
				}
			});
	});
});