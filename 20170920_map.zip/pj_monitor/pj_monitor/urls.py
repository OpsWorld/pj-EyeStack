from django.conf.urls import patterns, include, url

#accounts
urlpatterns = patterns('',
    url(r'^accounts/',include('apps.accounts.urls' )),
)


from pj_monitor.views import Home, getMapData

#home
urlpatterns += patterns('',
    url(r'^monitor/map/$', Home),
    url(r'^getMapDataApi/(?P<ID>\d+)/$', getMapData),
)
