#-*- coding: utf-8 -*-
#__author__ = 'Zline'

from django.core.urlresolvers import reverse
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render_to_response,RequestContext
from django.contrib.auth.decorators import login_required
from libs.common.CommonPaginator import SelfPaginator
from libs.common.NoteLog import LogNote
from apps.accounts.views.permission import PermissionVerify

from apps.accounts.forms import RoleListForm
from apps.accounts.models import RoleList

@login_required
@PermissionVerify()
def AddRole(request):
    '''增加角色'''
    if request.method == "POST":
        form = RoleListForm(request.POST)
        if form.is_valid():
            form.save()
            LogNote(u'角色 - 新增 - 名称:{0}'.format(form.cleaned_data['name']), str(request.user))
            return HttpResponseRedirect(reverse('listroleurl'))
    else:
        form = RoleListForm()

    kwvars = {
        'form':form,
        'request':request,
    }

    return render_to_response('accounts/role.add.html',kwvars,RequestContext(request))

@login_required
@PermissionVerify()
def ListRole(request):
    '''角色列表'''
    # LogNote(u'角色 - 查看列表', str(request.user))
    mList = RoleList.objects.all()

    #分页功能
    lst = SelfPaginator(request,mList, 10)

    kwvars = {
        'lPage':lst,
        'request':request,
    }

    return render_to_response('accounts/role.list.html',kwvars,RequestContext(request))

@login_required
@PermissionVerify()
def EditRole(request,ID):
    '''编辑角色'''
    # LogNote(u'角色 - 修改 - id:{0}'.format(ID), str(request.user))
    iRole = RoleList.objects.get(id=ID)

    if request.method == "POST":
        form = RoleListForm(request.POST,instance=iRole)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('listroleurl'))
    else:
        form = RoleListForm(instance=iRole)

    kwvars = {
        'ID':ID,
        'form':form,
        'request':request,
    }

    return render_to_response('accounts/role.edit.html',kwvars,RequestContext(request))

@login_required
@PermissionVerify()
def DeleteRole(request,ID):
    '''删除角色'''
    # LogNote(u'用户 - 删除 - id:{0}'.format(ID), str(request.user))
    RoleList.objects.filter(id = ID).delete()

    return HttpResponseRedirect(reverse('listroleurl'))