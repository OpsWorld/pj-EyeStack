#-*- coding: utf-8 -*-
#__author__ = 'Zline'

from django.core.urlresolvers import reverse
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render_to_response,RequestContext
from django.contrib.auth.decorators import login_required
from libs.common.CommonPaginator import SelfPaginator
# from apps.accounts.views.permission import PermissionVerify

from django.contrib import auth
from django.contrib.auth import get_user_model



def LoginUser(request):
    '''用户登录view'''
    if request.user.is_authenticated():
        return HttpResponseRedirect('/')

    if request.method == 'GET' and request.GET.has_key('next'):
        next = request.GET['next']
    else:
        next = '/accounts/user/list/'

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username is not None and password is not None:
            user = auth.authenticate(username=username, password=password)
            if user is not None and user.is_active:
                auth.login(request,user)
                return HttpResponseRedirect(reverse('listuserurl'))
            else:
                return render_to_response('accounts/login.html', {'login_error':'用户名或密码错误!'})

    kwvars = {
        'request':request,
        'next':next,
    }
    return render_to_response('accounts/login.html', kwvars, RequestContext(request))

@login_required
def LogoutUser(request):
    '''用户退出'''
    auth.logout(request)
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

# @login_required
# def ChangePassword(request):
#     if request.method=='POST':
#         form = ChangePasswordForm(user=request.user,data=request.POST)
#         if form.is_valid():
#             form.save()
#             LogNote(u'用户 - 修改密码', str(request.user))
#             return HttpResponseRedirect(reverse('logouturl'))
#     else:
#         form = ChangePasswordForm(user=request.user)

#     kwvars = {
#         'form':form,
#         'request':request,
#     }

#     return render_to_response('accounts/password.change.html',kwvars,RequestContext(request))

@login_required
# @PermissionVerify()
def ListUser(request):
    # LogNote(u'用户 - 查看列表', str(request.user))
    mList = get_user_model().objects.all()

    #分页功能
    lst = SelfPaginator(request,mList, 10)

    kwvars = {
        'lPage':lst,
        'request':request,
    }

    return render_to_response('accounts/user.list.html', kwvars, RequestContext(request))

# @login_required
# @PermissionVerify()
# def AddUser(request):
#     if request.method=='POST':
#         form = AddUserForm(request.POST)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.set_password(form.cleaned_data['password'])
#             form.save()
#             LogNote(u'用户 - 新增 - 用户:{0}'.format(form.cleaned_data['username']), str(request.user))
#             return HttpResponseRedirect(reverse('listuserurl'))
#     else:
#         form = AddUserForm()

#     kwvars = {
#         'form':form,
#         'request':request,
#     }

#     return render_to_response('accounts/user.add.html',kwvars,RequestContext(request))

# @login_required
# @PermissionVerify()
# def EditUser(request,ID):
#     LogNote(u'用户 - 修改 - id:{0}'.format(ID), str(request.user))
#     user = get_user_model().objects.get(id = ID)

#     if request.method=='POST':
#         form = EditUserForm(request.POST,instance=user)
#         if form.is_valid():
#             form.save()
#             return HttpResponseRedirect(reverse('listuserurl'))
#     else:
#         form = EditUserForm(instance=user
#         )

#     kwvars = {
#         'ID':ID,
#         'form':form,
#         'request':request,
#     }

#     return render_to_response('accounts/user.edit.html',kwvars,RequestContext(request))

# @login_required
# @PermissionVerify()
# def DeleteUser(request,ID):
#     LogNote(u'用户 - 删除 - id:{0}'.format(ID), str(request.user))
#     if ID == '1':
#         return HttpResponse(u'超级管理员不允许删除!!!')
#     else:
#         get_user_model().objects.filter(id = ID).delete()

#     return HttpResponseRedirect(reverse('listuserurl'))

# @login_required
# @PermissionVerify()
# def ResetPassword(request,ID):
#     LogNote(u'用户 - 重置密码 - id:{0}'.format(ID), str(request.user))
#     user = get_user_model().objects.get(id = ID)

#     newpassword = get_user_model().objects.make_random_password(length=10,allowed_chars='abcdefghjklmnpqrstuvwxyABCDEFGHJKLMNPQRSTUVWXY3456789')
#     print '====>ResetPassword:%s-->%s' %(user.username,newpassword)
#     user.set_password(newpassword)
#     user.save()

#     kwvars = {
#         'object':user,
#         'newpassword':newpassword,
#         'request':request,
#     }

#     return render_to_response('accounts/password.reset.html',kwvars,RequestContext(request))
