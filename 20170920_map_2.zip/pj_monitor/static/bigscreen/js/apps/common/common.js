﻿/**
 * 公共组件封装成模块
 * @desc
 * @auth junji
 * @version 2017/8/14 13:10
 */
define(function (common) {
	var common = {
			count : 0,
			open : function(title,wh,url,btn,okFn,btn2,cancelFn){
				/**
				 * 弹出层封装
				 * @title		标题
				 * @wh			宽高度
				 * @url			IFrame打开url
				 * @btn			底部按钮字体
				 * @okFn		点击按钮回调函数
				 * @btn2		取消按钮回调
				 * @cancelFn	关闭按钮回调
				*/
			},
			msgBox : function(msg,icon){
				/**
				 * 成功、错误提示
				 * @msg			提示信息
				 * @icon    	icon-warning 提醒
								icon-success 成功
								icon-loading 加载
				*/
				this.count ++ ;
				var warning = '<div class="ifly-tips-box" id="ifly-tips-box-'+this.count +'"><div class="ifly-'+icon+'"></div>'+msg+'</div>';
				$('body').append(warning);
        		setTimeout("$('#ifly-tips-box-"+this.count+"').remove()", 2000 )
			},
			loading : function(flag){
				this.count ++ ;
				if(flag || arguments.length == ''){
					var warning = '<div class="ifly-tips-box" id="ifly-tips-box-'+this.count +'"><div class="ifly-icon-loading"></div>加载中…</div>';
					$('body').append(warning);	
				}else{
					$('#ifly-tips-box-"+this.count+"').remove();
				}
			},
			ajax : function(url, data, successfn, errorfn){
				/**
				* ajax封装
				* url 发送请求的地址
				* data 发送到服务器的数据，数组存储，如：{"date": new Date().getTime(), "state": 1}
				* dataType 预期服务器返回的数据类型，常用的如：xml、html、json、text
				* successfn 成功回调函数
				* errorfn 失败回调函数
				*/
				data = (data==null || data=="" || typeof(data)=="undefined")? {"date": new Date().getTime()} : data;
				$.ajax({
					type: "post",
					data: data,
					url: url,
					dataType: "json",
					success: function(d){
						successfn(d);
				},
				error: function(e){
						errorfn(e);
				}
			});
			},
			tips : function(obj){
				var a;
				$(obj).on('mouseenter', function () {
						a = layer.tips($(this).attr('tips'), this, {time: 0});
				}).on('mouseleave', function () {
						layer.close(a);
				})
			},
			tabs : function(obj, e){
				$(obj).on(e, function () {
					var ix = $(this).index(),
						tab = $(this).parent().siblings('ul').children('li');
					$(this).siblings().removeClass('ifly-box-title-this');
					$(this).addClass('ifly-box-title-this');
					tab.hide();
					tab.eq(ix).show();
				})
			},
			back : function(obj){
				$(obj).on('click',function(){
                	history.back(-1)
            	})
			}
		}
	return common
})
/*
 扩展方法
 */
$.fn.extend({
    //判断新闻标题文字超出增加省略号
    substr : function(option){
        var opt = ({},{
            num:65
        },option);
        return $(this).each(function() {
            var self = $(this),
                html  = self.html();
            if(html.length > opt.num){
                self.html(html.substr(0,opt.num)+'...')
            }
        })
    },
    //资讯标题超出提示
    totalNums : function(option){
        var opt=({},{
            num:30
        },option);

        var th = $(this);
        var warn = '<div class="ifly-warn-num">'+0+'/'+opt.num;
        th.after(warn);
        return th.each(function() {
            return th.on("keyup",function(){
                var self = $(this);
                if(self.val().length <= opt.num){
                    self.next(".warn-num").html(parseInt(self.val().length)+"/"+opt.num)
                }else{
                    self.val(self.val().substr(0,opt.num));
                    layer.msg("已超过规定字数！")
                }
            })
        })
    }
})