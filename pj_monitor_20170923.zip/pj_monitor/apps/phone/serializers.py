# -*- coding:utf-8 -*-

from rest_framework import serializers
from .models import AlarmPhone


class AlarmPhoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = AlarmPhone
        fields = ('id', 'call_time', 'phone_num', 'alarm_msg', 'call_resp')