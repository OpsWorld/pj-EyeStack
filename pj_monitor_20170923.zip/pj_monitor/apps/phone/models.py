# -*- coding:utf-8 -*-

from django.db import models

from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token
from django.conf import settings



@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)


class AlarmPhone(models.Model): 
    call_time = models.DateTimeField(u"时间", auto_now_add=True) 
    phone_num = models.CharField(u"手机号码", max_length=11)  
    alarm_msg = models.CharField(u"告警文本", max_length=255)
    call_resp = models.CharField(u"使用人", max_length=255)

    def __unicode__(self):
        return self.phone_num

    class Meta:
        db_table = "alarm_phone"    
        verbose_name = u"电话告警"
        verbose_name_plural = verbose_name   