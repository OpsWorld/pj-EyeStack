from django.conf.urls import patterns, include, url
# from rest_framework.authtoken import views
from .views import obtain_expiring_auth_token

#accounts
urlpatterns = patterns('',
    url(r'^accounts/',include('apps.accounts.urls' )),
)


from pj_monitor.views import Home, getMapData, AlarmTelNotice

#home
urlpatterns += patterns('',
    url(r'^monitor/map/$', Home),
    url(r'^getMapDataApi/(?P<ID>\d+)/$', getMapData),
)


#token
urlpatterns += patterns('',
    # url(r'^api-token-auth/', views.obtain_auth_token),
    url(r'^cgi-bin/application/GetAccessToken$', obtain_expiring_auth_token, name='api-token')    
)

#alarm notice phone api
urlpatterns += patterns('',
    url(r'^cgi-bin/application/AlarmPhoneNoticeApi$', AlarmTelNotice),
)

