#-*- coding: utf-8 -*-

from django.shortcuts import render_to_response
from django.http import HttpResponse
import os, sys
import urllib2
import json
from django.contrib.auth.decorators import login_required
import re
from libs.common.PhoneNumValite import PhoneIsValid
from libs.common.CommonPhoneApi import ivrVoiceNotice

from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics

from django.core import serializers
from apps.phone.serializers import AlarmPhoneSerializer
from apps.phone.models import AlarmPhone

import datetime
from django.conf import settings
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken

from django.contrib.auth.tokens import default_token_generator  
 
EXPIRE_MINUTES = getattr(settings, 'REST_FRAMEWORK_TOKEN_EXPIRE_MINUTES', 60)
 
class ObtainExpiringAuthToken(ObtainAuthToken):
    """Create user token"""
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            token, created =  Token.objects.get_or_create(user=serializer.validated_data['user'])
 
            time_now = datetime.datetime.now()
 
            if created or token.created < time_now - datetime.timedelta(minutes=EXPIRE_MINUTES):
                # Update the created time of the token to keep it valid
                token.delete()
                token = Token.objects.create(user=serializer.validated_data['user'])
                token.created = time_now
                token.save()
 
            return Response({'token': token.key})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
 
obtain_expiring_auth_token = ObtainExpiringAuthToken.as_view()


@login_required
def Home(request):
	return render_to_response('bigscreen/index.html')



def getMapData(request, ID):
	if str(ID) == '10000':
		url = 'http://172.16.100.21/url/index.php/Map/data?type=ct'
		print url
	elif str(ID) == '10010':
	    url = 'http://172.16.100.21/url/index.php/Map/data?type=cu'
	    print url
	elif str(ID) == '10086':
		url = 'http://172.16.100.21/url/index.php/Map/data?type=cm'
		print url
	else:
		pass
	req = urllib2.Request(url)
	result = urllib2.urlopen(req)
	res = result.read() 
	data_info = json.loads(res) 
	return HttpResponse(json.dumps(data_info), content_type="application/json")


# @api_view(['GET', ])
# def AlarmTelNotice(request):
#     tel_num = request.GET.get('tel_num')
#     msg = request.GET.get('msg')
#     phone = PhoneIsValid(tel_num)
#     if phone == 40001:    	
#         return HttpResponse('{"code": 40001, "msg":"phone number is error!"}')
#     else:
#     	# ret = ivrVoiceNotice(phone)
#         return HttpResponse('{"code": 0, "msg":"success!"}')



@api_view([ 'POST','GET',])
def AlarmTelNotice(request):
	# if request.user.is_authenticated(): 
    if request.method == 'GET':
    	call_resp = request.GET.get('call_resp')
        asset_list = AlarmPhone.objects.filter(call_resp=call_resp)
        serializer = AlarmPhoneSerializer(asset_list,many=True)
        return Response(serializer.data)


    elif request.method == 'POST':
        serializer = AlarmPhoneSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            phone = PhoneIsValid(request.data['phone_num'])
            print phone
            if phone == 40001:
                return HttpResponse('{"code": 40001, "msg":"phone number is error!"}')
            else:
                ret = ivrVoiceNotice(phone)
                return HttpResponse('{"code": 0, "msg":"success!"}')                	
        else:
            return HttpResponse('{"code": 50001, "msg":"params is error!"}')       