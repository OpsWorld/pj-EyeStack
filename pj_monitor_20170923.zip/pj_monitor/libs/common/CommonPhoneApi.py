#-*- coding: utf-8 -*-
#__author__ = 'lwhong'

import datetime
import hashlib
import json 
import urllib2
import random


dev_id = '43df3f2c1553e649'
app_id = '6242072e84af2866'
app_secret = '47a85f4f50471621'
caller_nbr = '055165309764'


def GetAccessToken():
    url = 'http://61.191.42.84:82/abilityiservuc/api/version/43df3f2c1553e649/6242072e84af2866/common/GetAccessToken'
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    msrc = '{0}{1}{2}'.format(dev_id, app_secret, timestamp)
    m2 = hashlib.md5()
    m2.update(msrc)
    authenticator = m2.hexdigest()
    data = {'timestamp':timestamp, 'token_type':'server', 'authenticator':authenticator} 
    headers = {'Content-Type': 'application/json'}
    request = urllib2.Request(url=url, headers=headers, data=json.dumps(data))
    response = urllib2.urlopen(request)
    res = response.read()
    return json.loads(res)
    

def ivrVoiceNotice(callee_nbr):
    url = 'http://61.191.42.84:82/abilityiservuc/api/version/43df3f2c1553e649/6242072e84af2866/ivr/ivrVoiceNotice'
    token = GetAccessToken()
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    msrc = '{0}{1}{2}'.format(dev_id, app_secret, timestamp)
    m2 = hashlib.md5()
    m2.update(msrc)
    request_id = '{0}0{1}{2}{3}{4}'.format(datetime.datetime.now().strftime('%Y%m%d%H%M'), random.randint(0,9), random.randint(0,9), random.randint(0,9), random.randint(0,9))   
    authenticator = m2.hexdigest()
    data = {'body':{
                    'user_data': '',
                    'caller_nbr': caller_nbr,
                    'request_id': request_id,
                    'play_times': '1',
                    'callee_nbr': callee_nbr,
                    'callback_url': '',
                    'voice_id': 'D00001999'
            }, 
            'head':{
                     'timestamp': timestamp,
                     'authenticator': authenticator,
                     'access_token': token['access_token']
            }
    } 
    headers = {'Content-Type': 'application/json'}
    request = urllib2.Request(url=url, headers=headers, data=json.dumps(data))
    response = urllib2.urlopen(request)
    res = response.read()
    return json.loads(res)