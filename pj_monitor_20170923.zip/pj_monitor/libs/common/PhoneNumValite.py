#-*- coding: utf-8 -*-
#__author__ = 'lwhong'

import re 


def PhoneIsValid(phone):
    '''
    验证电话号码是否有效
    '''
    p2 = re.compile('^[1][3,4,5,7,8][0-9]{9}$')
    phonematch = p2.match(phone) 
    if phonematch:
        return phonematch.group()
    else:
        return 40001