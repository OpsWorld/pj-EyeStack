﻿/**
 * config模块配置
 * @desc
 * @auth junji
 * @version 2017/8/14 13:10
 */
var require = {
    /**
     * bserUrl：用来配置模块根目录，路径相对于HTML
     * 通过 data-main="../apps/index/index" 加载模块JS
     */
    baseUrl:"/static/bigscreen/js/plugins",

    /**
	 *	 map：require js默认不支持css异步加载的，这里引入了require-css，用来关联组件CSS；
     * paths：用来映射基于根路径下面的模块路径
     */
	map: {
      '*': {
        'css': 'require-css1.0/css'
      }
    },
    paths: {
        'jquery' : 'jquery-1.7.2/jquery',
        'layer' : 'layer1.0/layer',
        'common' : '../apps/common/common',
        'template' : 'template1.0/template',
        'pagination' : 'jquery.simplePagination1.0/pagination',
        'ztree' : 'jquery.ztree1.0/ztree',
        'WdatePicker' : 'My97DatePicker4.8/WdatePicker',
        'scrollbar' : 'jquery.mCustomScrollbar1.0/scrollbar',
        'iflyPieChart' : 'iflyPieChart/iflyPieChart',
        'fullpage': 'fullpage/jquery.fullpage',
        'echarts':'echart/echarts.min',
        'china':'echart/map/js/china'
    },
    /**
     * 	  shim：用来配置不兼容的模块（不符合AMD规范的JS组件），如：加载某个没有返回值的对象方法，让require支持obj.init()调用，通过exports属性即可；
	 *    deps：表明该模块的依赖性，如：当编写组件依赖于jquery，则在组件引用时自动加载jquery，另外通过require-css组件加载，支持css自动引用页面，无需在页面<link>写入；
     * exports：指的是这个模块外部调用时的名称，务必确保组件paths、shim、define、项目名称、文件夹保持一样；
	 *  define：['SuperSlide'], function(SuperSlide){} 依赖组件
     */
    shim: {
        'jquery': {
            exports: 'jquery'
        },
        'layer': {
            deps :[
                'jquery',
                'css!layer/layer'
            ],
            exports: 'layer'
        },
        'common': {
            deps: ['jquery'],
            exports: 'common'
        },
        'template': {
            deps: ['jquery'],
            exports: 'template'
        },
        'pagination': {
            deps : [
				'jquery',
                'css!jquery.simplePagination1.0/pagination'
            ],
            exports: 'pagination'
        },
        'ztree': {
            deps: ['jquery'],
            exports: 'ztree'
        },
        'jedate': {
            deps: ['jquery'],
            exports: 'jedate'
        },
        'scrollbar': {
            deps : [
                'jquery',
                'css!scrollbar'
            ],
            exports: 'scrollbar'
        },
        'WdatePicker': {
            deps: [
				'jquery',
                'css!My97DatePicker4.8/skin/WdatePicker'
            ],
            exports: 'WdatePicker'
        },
        'iflyPieChart': {
            deps: [
                'jquery',
                'css!iflyPieChart'
            ],
            exports: 'iflyPieChart'
        },
        'fullpage':{
            deps: [
                'jquery',
                'css!fullpage'
            ],
            exports: 'fullpage'
        }
    }
};